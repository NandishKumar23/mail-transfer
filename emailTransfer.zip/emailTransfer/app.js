const  express=require("express")
const app=express()
const nodemailer=require('nodemailer')
 let transpoter=nodemailer.createTransport({
     service:"gmail",
     auth:{
         user:"nandishkumar2312@gmail.com",
         pass:"23122000134462"
     },
     tls:{
         rejectUnauthorized:false
     }
     
 })
 let mailoptions={
     from:"nandishkumar2312@gmail.com",
     to:"prajwalpr2@gmail.com",
     subject:"testing",
     text:"Hi this is a mail for testing purpose .PP Nodemailer inda bandiradu  "
 }
 transpoter.sendMail( mailoptions,function(err,success){
     if(err){
         console.log(err)
     }else{
         console.log("Email sent successfully")
     }
 })
app.get("/",function(req,res){
      res.send("hello world")
})
app.listen(3000,function(){
    console.log("Server ready at port 3000");
})
